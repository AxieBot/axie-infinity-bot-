import os

haarcascades = os.path.join(os.path.dirname(__file__), "")
