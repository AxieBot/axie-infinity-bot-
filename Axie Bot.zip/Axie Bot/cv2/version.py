opencv_version = "4.5.4.60"
contrib = False
headless = False
ci_build = True